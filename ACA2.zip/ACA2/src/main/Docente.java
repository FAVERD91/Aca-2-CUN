package main;
import javax.swing.JOptionPane;

/**
 * Esta es la clase docente, en ella encontraremos toda la informacion en cuanto al docente que trabajara en la universidad.
 * @author Faver Delgado
 *
 */

public class Docente {
	
	int Cod_Docente, sueldo;
	String Nom_Docente, Ape_Docente,Prog_Docente, Tipo_Contratacion;
	/**
	 * Este apartado contiene todas las variables que hemos declarado dentro de la clase Docente.
	 */
	public void Contratar()
	{
		Cod_Docente = Integer.parseInt(JOptionPane.showInputDialog("Ingrese El Codigo Del Docente Que Desea Contratar"));
		Nom_Docente = JOptionPane.showInputDialog("Ingrese Los Nombres Del Docente");
		Ape_Docente = JOptionPane.showInputDialog("Ingrese Los Apellidos Del Docente");
		Tipo_Contratacion = JOptionPane.showInputDialog("Ingrese El Tipo De Contratacion Que Tendra El Docente");
		sueldo = Integer.parseInt(JOptionPane.showInputDialog("Ingrese El Sueldo Del Docente Que Desea Contratar"));
		Prog_Docente = JOptionPane.showInputDialog("Ingrese El Programa Que Tendra El Docente");
		
    	JOptionPane.showMessageDialog(null,"El Codigo Del Docente Contratado Es: " + Cod_Docente);
    	JOptionPane.showMessageDialog(null,"El Nombre Del Docente Es: " + Nom_Docente);   	
    	JOptionPane.showMessageDialog(null,"El Apellido Del Docente Es: " + Ape_Docente);
    	JOptionPane.showMessageDialog(null,"El Tipo De Contrato Es: " + Tipo_Contratacion);
    	JOptionPane.showMessageDialog(null,"El Sueldo Del Docente Contratado Es: " + sueldo);
    	JOptionPane.showMessageDialog(null,"El Programa Inscrito Para El Docente Es: " + Prog_Docente);
	}
	
	/**
	 * En este metodo encontramos la informacion solicitada para contratar algun docente en la universidad.
	 */
	
	public void Cambiar_Asignatura()
	{
		Cod_Docente = Integer.parseInt(JOptionPane.showInputDialog("Ingrese El Codigo Del Docente Que Desea Cambiar"));
		Prog_Docente = JOptionPane.showInputDialog("Ingrese El Programa Que Tendra El Docente");
		
    	JOptionPane.showMessageDialog(null,"El Codigo Del Docente Asignado Es: " + Cod_Docente);
    	JOptionPane.showMessageDialog(null,"El Programa Inscrito Para El Docente Es: " + Prog_Docente);  	
	}
	/**
	 * Para este metodo encontraremos la opcion de cambiar la asignatura que tiene cargada el docente.
	 */
	public void Cambiar_Tipo_Contrato()
	{
		Cod_Docente = Integer.parseInt(JOptionPane.showInputDialog("Ingrese El Codigo Del Docente Que Desea Cambiar"));
		Tipo_Contratacion = JOptionPane.showInputDialog("Ingrese El Tipo De Contratacion Que Tendra El Docente");
		sueldo = Integer.parseInt(JOptionPane.showInputDialog("Ingrese El Sueldo Del Docente Que Desea Cambiar"));
		
    	JOptionPane.showMessageDialog(null,"El Codigo Del Docente Asignado Es: " + Cod_Docente);    	
    	JOptionPane.showMessageDialog(null,"El Tipo De Contrato Es: " + Tipo_Contratacion);
    	JOptionPane.showMessageDialog(null,"El Sueldo Del Docente Ajustado Es: " + sueldo);
	}
	
	/**
	 * En este metodo tenemos la opcion de generar el cambio del tipo de contrato que maneja el docente.
	 */
	
	public void Despedir()
	{
		Cod_Docente = Integer.parseInt(JOptionPane.showInputDialog("Ingrese El Codigo Del Docente Que Desea Despedir"));
		Nom_Docente = JOptionPane.showInputDialog("Ingrese Los Nombres Del Docente Que Va a Despedir");
		Ape_Docente = JOptionPane.showInputDialog("Ingrese Los Apellidos Del Docente Que Va a Despedir");
		
    	JOptionPane.showMessageDialog(null,"El Codigo Del Docente Despedido Es: " + Cod_Docente);
    	JOptionPane.showMessageDialog(null,"El Nombre Del Docente Despedido Es: " + Nom_Docente);
    	JOptionPane.showMessageDialog(null,"El Apellido Del Docente Despedido Es: " + Ape_Docente);    	
	}
	
	/**
	 * En este metodo usaremos la informacion del docente que fue despedido o se le finalizo el contrato.
	 */
	
	public void Capacitar()
	{
		Cod_Docente = Integer.parseInt(JOptionPane.showInputDialog("Ingrese El Codigo Del Docente Que Desea Capacitar"));
		Nom_Docente = JOptionPane.showInputDialog("Ingrese Los Nombres Del Docente Que Va a Capacitar");
		Ape_Docente = JOptionPane.showInputDialog("Ingrese Los Apellidos Del Docente Que Va a Capacitar");
		
		JOptionPane.showMessageDialog(null,"El Codigo Del Docente Que Asistira A Capacitacion Es: " + Cod_Docente);
    	JOptionPane.showMessageDialog(null,"El Nombre Del Docente Que Asistira A Capacitacion Es: " + Nom_Docente);
    	JOptionPane.showMessageDialog(null,"El Apellido Del Docente Que Asistira A Capacitacion Es: " + Ape_Docente);  
	}
	
	/**
	 * En este metodo encontramos las opciones para realizar el registro del docente que sera capacitado por parte de la universidad
	 */
	
	public void Promover()
	{
		Cod_Docente = Integer.parseInt(JOptionPane.showInputDialog("Ingrese El Codigo Del Docente Que Desea Promover"));
		Nom_Docente = JOptionPane.showInputDialog("Ingrese Los Nombres Del Docente Que Va a Promover");
		Ape_Docente = JOptionPane.showInputDialog("Ingrese Los Apellidos Del Docente Que Va a Promover");
		
		JOptionPane.showMessageDialog(null,"El Codigo Del Docente Que Sera Promovida Es: " + Cod_Docente);
    	JOptionPane.showMessageDialog(null,"El Nombre Del Docente Que Sera Promovida Es: " + Nom_Docente);
    	JOptionPane.showMessageDialog(null,"El Apellido Del Docente Que Sera Promovida Es: " + Ape_Docente); 
	}
	
	/**
	 * En este metodo encontramos la opcion de promover al docente dentro de la universidad.
	 */
	

}
