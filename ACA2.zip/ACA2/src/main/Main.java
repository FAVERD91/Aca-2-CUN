package main;

/**
 * Esta es la clase principal en la cual se genera la ejecucion de las instancias de las demas clases que se crearon.
 * @author Faver Delgado
 *
 */

public class Main {
	
	public static void main(String[]args) {

		/**
		 * Aca encontramos la instancia que llama al objeto Universidad.		
		 */
		Universidad U = new Universidad();
				 
		U.Reg_Cod_Est();
		U.Reg_Cod_Programa();
		U.Reg_Cod_Profesor();

		/**
		 * Aca encontramos la instancia que llama al objeto Estudiante.
		 */
		
		Estudiante E = new Estudiante();
		
		E.Reg_Estudiante();
		E.Modificar_Datos();
		E.Eliminar_Datos();
		E.Cambiar_Programa();
		
		/**
		 * Aca encontramos la instancia que llama al objeto Materias.
		 */
		
		Materias M = new Materias();
		
		M.Cambiar_Cod_Prof();
		M.Cambiar_Grupo();
		M.Cambiar_Horario();
		M.Cambiar_Salon();
		M.Cambiar_Sede();
		
		/**
		 * Aca encontramos la instancia que llama al objeto Docente.
		 */
		
		Docente D = new Docente();
		
		D.Cambiar_Asignatura();
		D.Cambiar_Tipo_Contrato();
		D.Capacitar();
		D.Contratar();
		D.Despedir();
		
		/**
		 * Aca encontramos la instancia que llama al objeto Facultad.
		 */
		
		Facultad F = new Facultad();
		
		F.Cam_Sede_Facultad();
		F.Cambiar_Cod_Materias();
		F.Cambiar_Decano();
		
	}

}
