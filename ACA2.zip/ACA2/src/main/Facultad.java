package main;
import javax.swing.JOptionPane;

/**
 * Esta es la clase Facultad en ella encontramos la informacion de las facultades que maneja la universidad
 * @author Users
 *
 */

public class Facultad {
	
	int Cod_Facultad, Cod_Materia;
	String Nom_Facultad, Sed_Facultad,Decano_Facultad;
	/**
	 * Aca encontramos la declaracion de las variables que se utilizan en la clase.
	 */
	public void Cam_Sede_Facultad()
	{
		Cod_Facultad = Integer.parseInt(JOptionPane.showInputDialog("Ingrese El Codigo De La facultad Que Desea Cambiar"));
		Nom_Facultad = JOptionPane.showInputDialog("Ingrese El Nombre De La Facultad Que Desea Cambiar");
		Sed_Facultad = JOptionPane.showInputDialog("Ingrese El Nombre De La Sede Que Desea Cambiar");
		
		JOptionPane.showMessageDialog(null,"El Codigo Del Docente Contratado Es: " + Cod_Facultad);
    	JOptionPane.showMessageDialog(null,"El Nombre De La facultad Es: " + Nom_Facultad);   	
    	JOptionPane.showMessageDialog(null,"La Sede ASignada Es: " + Sed_Facultad);
	}
	
	/**
	 * En este metodo encontramos la opcion de generar el cambio de sede de la facultad.
	 */
	
	public void Cambiar_Decano()
	{
		Decano_Facultad = JOptionPane.showInputDialog("Ingrese El Nombre Del Decano Que Desea Cambiar");
		
		JOptionPane.showMessageDialog(null,"El Nombre Del Nuevo Decano Es: " + Decano_Facultad);
	}
	
	/**
	 * En este metodo podremos generar el cambio del nombre del decano que tenga a cargo la facultad.
	 */
	
	public void Cambiar_Cod_Materias()
	{
		Cod_Materia = Integer.parseInt(JOptionPane.showInputDialog("Ingrese El Codigo De La Materia Que Desea Cambiar"));
		
		JOptionPane.showMessageDialog(null,"El Codigo De La Nueva Materia Es: " + Cod_Materia);
	}
	
	/**
	 * En este metodo podremos generar el cambio de codigo de las materias que seran vista en los semestres.
	 */

}
