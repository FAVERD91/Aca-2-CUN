package main;
import javax.swing.JOptionPane;

/**
 * Universidad representa la clase en la que encotramos la informacion de la universidad como los codigos de programa que maneja, la generacion del codigo de los estudiantes que ingresan a la universidad
 * tambien encontraremos la posiblidad de registrar la informacion de los docentes que laboran en la universidad, junto a lo anterior encontraremos tambien las sede con las que cuenta la universidad
 * y el costo de los semestres.
 * @author Faver Delgado
 *
 */

public class Universidad {

	int Cod_Programa, Cod_Estudiante, Cod_Docente, Valor_Semestre;
    String Sedes;
 /**
  * En este apartado encontraremos la declaracion de las variables que se usaron en la clase.
  */
    public void Reg_Cod_Est()
    {
    	Cod_Estudiante= Integer.parseInt(JOptionPane.showInputDialog("Ingrese El Codigo del Estudiante"));
    	JOptionPane.showMessageDialog(null,"El Codigo Del Programa Es: " + Cod_Estudiante);
    }
/**
 * En este apartado encontramos el primer metodo en el que nos solicitan ingresar el codigo del estudiante y por medio de presentacion de pantalla nos mostrara el dato que acabamos de ingresar.
 */
    public void Reg_Cod_Programa()
    {
    	Cod_Programa= Integer.parseInt(JOptionPane.showInputDialog("Ingrese El Codigo del Programa"));
    	JOptionPane.showMessageDialog(null,"El Codigo Del Programa Es: " + Cod_Programa);
    }
/**
 * En este apartado encontramos otro metodo constructor, en el vamos a encontrar la opcion de ingresar el codigo del programa al que pertenece un estuadiante, y a vuelta de esto nos devolvera por pantalla la informacion ingresada 
 */
    public void Reg_Cod_Profesor()
    {
    	Cod_Docente= Integer.parseInt(JOptionPane.showInputDialog("Ingrese El Codigo del Docente"));
    	JOptionPane.showMessageDialog(null,"El Codigo Del Docente Es: " + Cod_Docente);
    }
/**
 * En este apartado encontramos otro metodo constructor, el cual recibe el codigo del docente que tiene contratado la universidad    
 */
    public void Sedes_Disponibles()
    {
    	Sedes= JOptionPane.showInputDialog("Ingrese La Sede Asignada");
    	JOptionPane.showMessageDialog(null,"La Sede Asignada Es: " + Sedes);
    }
/**
 * En este ultimo apartado de nuestra clase de Universidad, encontraremos la opcion de ingresar la sede asignada que tiene tanto un estudiante como un docente dependiendo del rol que se tenga registrado en la uniersidad     
 */
    
}
