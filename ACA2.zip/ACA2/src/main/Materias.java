package main;
import javax.swing.JOptionPane;

/**
 * Esta es la clase Materias, en ella encontremos toda la informacion y opciones que podremos realizar para este modulo.
 * @author Faver Delgado
 *
 */

public class Materias {
	
	int Cod_Materia, Credito_Materia,Cod_Prof_Asig,Cod_Grup_Asig;
	String Horario, Sede_Asignada,Salon_Asignado;

	/**
	 *En este apartado encontramos la declaracion de la variables que manejara la clase Materias.
	 */
	
	
	public void Cambiar_Cod_Prof()
	{
		Cod_Prof_Asig = Integer.parseInt(JOptionPane.showInputDialog("Ingrese El Codigo Del Docente Que Desea Cambiar"));
    	JOptionPane.showMessageDialog(null,"El Codigo Del Nuevo Docente Es: " + Cod_Prof_Asig);
	}
/**
 * En este metodo encontramos la opcion de cambiar el docente asignado a la materia ya que al momento de ser creada este genera la asignacion de uno docente de manera aleatoria.	
 */
	public void Cambiar_Horario()
	{
		Horario = JOptionPane.showInputDialog("Ingrese El Nuevo Horario De La Materia");
    	JOptionPane.showMessageDialog(null,"El Nuevo Horario Es: " + Horario);
	}
/**
 * En este metodo encontramos la opcion de cambiar el horario que la materia tendra ya que esta es generada de manera aleatoria despues de la creacion de la materia.
 */
	public void Cambiar_Sede() 
	{
		Sede_Asignada = JOptionPane.showInputDialog("Ingrese La Nueva Sede De La Materia");
    	JOptionPane.showMessageDialog(null,"La Nueva Sede Es: " + Sede_Asignada);
	}
/**
 * En este metodo encontramos la opcion de asignar la sede en la que se dictara la materia, esto debido a que al momento de crear la materia esta asigna una sede aleatoria.	
 */
	public void Cambiar_Salon()
	{
		Salon_Asignado = JOptionPane.showInputDialog("Ingrese El Salon De La Materia");
    	JOptionPane.showMessageDialog(null,"El Nuevo Salon Es: " + Salon_Asignado);
	}
/**
 * En este metodo encontraos la opcion de cambiar el salon asignado, esto debido a que al momento de crear la materia esta asigna una salon aleatorio.
 */
	public void Cambiar_Grupo()
	{
		Cod_Grup_Asig = Integer.parseInt(JOptionPane.showInputDialog("Ingrese El Codigo Del Grupo Que Desea Cambiar"));
    	JOptionPane.showMessageDialog(null,"El Codigo Del Nuevo Grupo Es: " + Cod_Grup_Asig);
	}
	
	/**
	 * En este metodo se genera el cambio del grupo al que pertenece la materia creada, esto debido a que al momento de crear la materia esta asigna un grupo aleatorio.
	 */
}
