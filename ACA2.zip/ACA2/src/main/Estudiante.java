package main;
import javax.swing.JOptionPane;

/**
 * Esta es la clase Estudiante, en ella encontraremos toda la informacion de los estuadiantes registrados.
 * @author Faver Delgado
 *
 */

public class Estudiante {

	int Cod_Estudiante,Valor_Semestre,Cod_Programa;
	String Nom_Estudiante,Ape_Estudiante,Nom_Facultad;
/**
 * En este apartado encontraremos la declaracion de las variables que utilizaremos en la clase.
 */
	public void Reg_Estudiante()
	{
		Cod_Estudiante = Integer.parseInt(JOptionPane.showInputDialog("Ingrese El Codigo Del Estudiante"));
		Nom_Estudiante = JOptionPane.showInputDialog("Ingrese Los Nombres Del Estudiante");
		Ape_Estudiante = JOptionPane.showInputDialog("Ingrese Los Apellidos Del Estudiante");
		Cod_Programa = Integer.parseInt(JOptionPane.showInputDialog("Ingrese El Codigo Del Programa"));
		Nom_Facultad = JOptionPane.showInputDialog("Ingrese El Nombre Del Programa");
		Valor_Semestre = Integer.parseInt(JOptionPane.showInputDialog("Ingrese El Valor Del Semestre"));
		
    	JOptionPane.showMessageDialog(null,"El Codigo Del Estudiante Es: " + Cod_Estudiante);
    	JOptionPane.showMessageDialog(null,"El Nombre Del Estudiante Es: " + Nom_Estudiante);
    	JOptionPane.showMessageDialog(null,"El Apellido Del Estudiante Es: " + Ape_Estudiante); 	
    	JOptionPane.showMessageDialog(null,"El Codigo Del Programa Es: " + Cod_Programa);    	
    	JOptionPane.showMessageDialog(null,"El Nombre Del Programa Es: " + Nom_Facultad);    	
    	JOptionPane.showMessageDialog(null,"El Valor Del Semestre Es: " + Valor_Semestre);
	}
	
/**
 * En este apartado se encontraran con el primer metodo de la clase, en el encontraremos la opcion de registrar a los nuevos estuadiantes que ingresan a la universidad	
 */
	
	public void Modificar_Datos()
	{
		Cod_Estudiante = Integer.parseInt(JOptionPane.showInputDialog("Ingrese El Codigo Del Estudiante Que Desea Cambiar"));
		Nom_Estudiante = JOptionPane.showInputDialog("Ingrese Los Nombres Corregidos Del Estudiante");
		Ape_Estudiante = JOptionPane.showInputDialog("Ingrese Los Apellidos Corregidos Del Estudiante");
		Cod_Programa = Integer.parseInt(JOptionPane.showInputDialog("Ingrese El Nuevo Codigo Del Programa"));
		Nom_Facultad = JOptionPane.showInputDialog("Ingrese El Nuevo Nombre Del Programa");
		Valor_Semestre = Integer.parseInt(JOptionPane.showInputDialog("Ingrese El Ajuste Al Valor Del Semestre"));
		
    	JOptionPane.showMessageDialog(null,"El Nuevo Codigo Del Estudiante Es: " + Cod_Estudiante);    	
    	JOptionPane.showMessageDialog(null,"El Nuevo Nombre Del Estudiante Es: " + Nom_Estudiante);    	
    	JOptionPane.showMessageDialog(null,"El Nuevo Apellido Del Estudiante Es: " + Ape_Estudiante);    	
    	JOptionPane.showMessageDialog(null,"El Nuevo Codigo Del Programa Es: " + Cod_Programa);    	
    	JOptionPane.showMessageDialog(null,"El Nuevo Nombre Del Programa Es: " + Nom_Facultad);    	
    	JOptionPane.showMessageDialog(null,"El Nuevo Valor Del Semestre Es: " + Valor_Semestre);
	}
	
	/**
	 * En este metodo encontraremos la opcion de modificar los datos de los estuadiantes previamente ya registrados.
	 */
	
	public void Eliminar_Datos()
	{
		Cod_Estudiante = Integer.parseInt(JOptionPane.showInputDialog("Ingrese El Codigo Del Estudiante Que Desea Eliminar"));
		Nom_Estudiante = JOptionPane.showInputDialog("Ingrese Los Nombres Del Estudiante Que Desea Eliminar");
		Ape_Estudiante = JOptionPane.showInputDialog("Ingrese Los Apellidos Corregidos Del Estudiante Que Desea Eliminar");
		Ape_Estudiante = JOptionPane.showInputDialog("Ingrese Los Apellidos Corregidos Del Estudiante Que Desea Eliminar");
		Cod_Programa = Integer.parseInt(JOptionPane.showInputDialog("Ingrese El Codigo Del Programa Que Desea Eliminar"));
		Nom_Facultad = JOptionPane.showInputDialog("Ingrese El Nombre Del Programa Que Desea Eliminar");
		Valor_Semestre = Integer.parseInt(JOptionPane.showInputDialog("Ingrese El Valor Del Semestre A Eliminar"));
		
    	JOptionPane.showMessageDialog(null,"El Codigo Del Estudiante Eliminado Es: " + Cod_Estudiante);    	
    	JOptionPane.showMessageDialog(null,"El Nombre Del Estudiante Eliminado Es: " + Nom_Estudiante);    	
    	JOptionPane.showMessageDialog(null,"El Apellido Del Estudiante Eliminado Es: " + Ape_Estudiante);    	
    	JOptionPane.showMessageDialog(null,"El Codigo Del Programa Eliminado Del Estudiante" + Cod_Estudiante + " Es: " + Cod_Programa);   	
    	JOptionPane.showMessageDialog(null,"El Nombre Del Programa Eliminado Del Estudiante" + Cod_Estudiante + " Es: " + Nom_Facultad);    	
    	JOptionPane.showMessageDialog(null,"El Valor Del Semestre Eliminado Para El Estudiante" + Cod_Estudiante + " Es: " + Valor_Semestre);
	}
	
	/**
	 * En este metodo se encontrara la opci�n de eliminar los datos ingresados de los estuadiantes
	 */
	
	public void Cambiar_Programa()
	{
		Cod_Programa = Integer.parseInt(JOptionPane.showInputDialog("Ingrese El Nuevo Codigo Del Programa"));
		Nom_Facultad = JOptionPane.showInputDialog("Ingrese El Nuevo Nombre Del Programa");
		
    	JOptionPane.showMessageDialog(null,"El Nuevo Codigo Del Programa Es: " + Cod_Programa);    	
    	JOptionPane.showMessageDialog(null,"El Nuevo Nombre Del Programa Es: " + Nom_Facultad);
	}
	
	/**
	 * En este metodo se encuentra la opcion de generar el cambio del programa del estudiante que haya realizado la solicitud formal ante la decanatura del programa al que desea cambiarse.
	 */
}
